import { useEffect, useState } from 'react';
import { Linkedin, Github, User } from 'lucide-react';
import { supabase, type TeamMember } from '../lib/supabase';
import { useScrollAnimation } from './useScrollAnimation';

const fallbackTeam: TeamMember[] = [
  { id: '1', name: 'Alex Rivera', role: 'Lead Developer', bio: 'Full-stack engineer with 5+ years building scalable web applications.', image_url: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400', linkedin_url: '#', github_url: '#', display_order: 1 },
  { id: '2', name: 'Maria Santos', role: 'UI/UX Designer', bio: 'Creative designer passionate about crafting beautiful user experiences.', image_url: 'https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg?auto=compress&cs=tinysrgb&w=400', linkedin_url: '#', github_url: '#', display_order: 2 },
  { id: '3', name: 'James Chen', role: 'Backend Engineer', bio: 'Systems architect specializing in high-performance APIs and databases.', image_url: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400', linkedin_url: '#', github_url: '#', display_order: 3 },
  { id: '4', name: 'Sofia Reyes', role: 'Project Manager', bio: 'Agile PM ensuring projects are delivered on time and exceed expectations.', image_url: 'https://images.pexels.com/photos/3756679/pexels-photo-3756679.jpeg?auto=compress&cs=tinysrgb&w=400', linkedin_url: '#', github_url: '#', display_order: 4 },
];

export default function Team() {
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const titleRef = useScrollAnimation();

  useEffect(() => {
    async function fetchTeam() {
      try {
        const { data, error } = await supabase.from('team_members').select('*').order('display_order');
        if (error || !data || data.length === 0) {
          setTeamMembers(fallbackTeam);
        } else {
          setTeamMembers(data);
        }
      } catch {
        setTeamMembers(fallbackTeam);
      }
    }
    fetchTeam();
  }, []);

  return (
    <section id="team" className="py-24 bg-yellow-400">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div ref={titleRef} className="text-center mb-16">
          <p className="text-black/50 text-xs font-bold uppercase tracking-[0.3em] mb-3">The People</p>
          <h2 className="text-4xl md:text-5xl font-black text-black uppercase">
            Meet Our <span className="underline decoration-black/30">Team</span>
          </h2>
          <p className="text-black/60 mt-4 max-w-xl mx-auto text-sm">
            Talented professionals dedicated to delivering exceptional results
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {teamMembers.map((member, index) => (
            <TeamCard key={member.id} member={member} delay={index * 100} />
          ))}
        </div>
      </div>
    </section>
  );
}

function TeamCard({ member, delay }: { member: TeamMember; delay: number }) {
  const ref = useScrollAnimation();
  return (
    <div
      ref={ref}
      style={{ transitionDelay: `${delay}ms` }}
      className="group bg-white hover:bg-black transition-all duration-300 p-6 text-center"
    >
      <div className="w-24 h-24 mx-auto mb-4 overflow-hidden bg-gray-100">
        {member.image_url ? (
          <img src={member.image_url} alt={member.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <User className="w-12 h-12 text-gray-400" />
          </div>
        )}
      </div>
      <h3 className="font-black text-black group-hover:text-white text-sm uppercase tracking-wide transition-colors">{member.name}</h3>
      <p className="text-yellow-500 text-xs font-bold uppercase tracking-widest my-1">{member.role}</p>
      <p className="text-gray-500 group-hover:text-gray-400 text-xs leading-relaxed mb-4 transition-colors">{member.bio}</p>
      <div className="flex justify-center gap-2">
        {member.linkedin_url && (
          <a href={member.linkedin_url} target="_blank" rel="noopener noreferrer"
            className="w-8 h-8 border border-gray-200 group-hover:border-yellow-400 flex items-center justify-center hover:bg-yellow-400 transition-all">
            <Linkedin className="w-4 h-4 text-gray-500 group-hover:text-black" />
          </a>
        )}
        {member.github_url && (
          <a href={member.github_url} target="_blank" rel="noopener noreferrer"
            className="w-8 h-8 border border-gray-200 group-hover:border-yellow-400 flex items-center justify-center hover:bg-yellow-400 transition-all">
            <Github className="w-4 h-4 text-gray-500 group-hover:text-black" />
          </a>
        )}
      </div>
    </div>
  );
}
