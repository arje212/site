import { Globe, Smartphone, Code2, Paintbrush, Headphones, Wrench } from 'lucide-react';
import { useScrollAnimation } from './useScrollAnimation';

export default function Services() {
  const titleRef = useScrollAnimation();

  const services = [
    { icon: Globe, title: 'Website Development', description: 'Custom, responsive websites built with modern technologies to establish your online presence.', features: ['Responsive Design', 'SEO Optimization', 'Performance Focused', 'CMS Integration'] },
    { icon: Smartphone, title: 'Web Application', description: 'Full-stack web applications tailored to your business needs with scalable architecture.', features: ['Custom Solutions', 'Real-time Features', 'Cloud Integration', 'API Development'] },
    { icon: Code2, title: 'System Development', description: 'Enterprise-grade systems and software solutions designed for efficiency and growth.', features: ['Database Design', 'System Architecture', 'Integration Services', 'Automation'] },
    { icon: Paintbrush, title: 'UI/UX Design', description: 'User-centered design that creates engaging and intuitive digital experiences.', features: ['User Research', 'Wireframing', 'Prototyping', 'Visual Design'] },
    { icon: Headphones, title: 'IT Consulting', description: 'Strategic technology guidance to help you make informed decisions and optimize processes.', features: ['Tech Strategy', 'Architecture Review', 'Best Practices', 'Digital Transformation'] },
    { icon: Wrench, title: 'Maintenance & Support', description: 'Ongoing support and maintenance to keep your systems running smoothly and securely.', features: ['24/7 Monitoring', 'Bug Fixes', 'Updates', 'Performance Optimization'] },
  ];

  return (
    <section id="services" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div ref={titleRef} className="mb-16">
          <p className="text-yellow-500 text-xs font-bold uppercase tracking-[0.3em] mb-3">What We Offer</p>
          <h2 className="text-4xl md:text-5xl font-black text-black uppercase leading-tight">
            Our <span className="text-yellow-400">Services</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-px bg-gray-200">
          {services.map((service, index) => (
            <ServiceCard key={index} service={service} delay={index * 80} />
          ))}
        </div>
      </div>
    </section>
  );
}

function ServiceCard({ service, delay }: { service: { icon: React.ElementType; title: string; description: string; features: string[] }; delay: number }) {
  const ref = useScrollAnimation();
  return (
    <div
      ref={ref}
      style={{ transitionDelay: `${delay}ms` }}
      className="group bg-white p-8 hover:bg-black transition-all duration-300"
    >
      <div className="w-14 h-14 bg-yellow-400 flex items-center justify-center mb-6 group-hover:bg-yellow-400 transition-colors">
        <service.icon className="w-7 h-7 text-black" />
      </div>
      <h3 className="text-base font-black uppercase text-black group-hover:text-white mb-3 tracking-wide transition-colors">{service.title}</h3>
      <p className="text-gray-500 group-hover:text-gray-400 text-sm mb-5 leading-relaxed transition-colors">{service.description}</p>
      <ul className="space-y-1">
        {service.features.map((f, i) => (
          <li key={i} className="flex items-center text-xs text-gray-400 group-hover:text-gray-500 transition-colors">
            <span className="w-1.5 h-1.5 bg-yellow-400 rounded-full mr-2 flex-shrink-0" />
            {f}
          </li>
        ))}
      </ul>
    </div>
  );
}
