import { useScrollAnimation } from './useScrollAnimation';

export default function Stats() {
  const ref = useScrollAnimation();

  const stats = [
    { number: '165', label: 'Projects Done' },
    { number: '24', label: 'Happy Clients' },
    { number: '8', label: 'Team Members' },
    { number: '82', label: 'Awards Won' },
  ];

  return (
    <section
      className="py-24 bg-cover bg-center bg-fixed relative"
      style={{ backgroundImage: "url('https://images.pexels.com/photos/3182812/pexels-photo-3182812.jpeg?auto=compress&cs=tinysrgb&w=1920')" }}
    >
      <div className="absolute inset-0 bg-black/75" />
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
        <div ref={ref} className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="col-span-2 md:col-span-1 flex flex-col justify-center">
            <p className="text-yellow-400 text-xs font-bold uppercase tracking-[0.3em] mb-3">Numbers</p>
            <h2 className="text-3xl font-black text-white uppercase leading-tight">
              Interesting<br />Facts
            </h2>
          </div>
          {stats.map((stat, i) => (
            <StatItem key={i} stat={stat} delay={i * 100} />
          ))}
        </div>
      </div>
    </section>
  );
}

function StatItem({ stat, delay }: { stat: { number: string; label: string }; delay: number }) {
  const ref = useScrollAnimation();
  return (
    <div ref={ref} style={{ transitionDelay: `${delay}ms` }} className="text-center">
      <div className="text-5xl md:text-6xl font-black text-yellow-400 mb-2">{stat.number}</div>
      <div className="text-gray-400 text-xs uppercase tracking-widest">{stat.label}</div>
    </div>
  );
}
