import { useState } from 'react';
import { Mail, Phone, MapPin, Send } from 'lucide-react';
import { supabase, type ContactSubmission } from '../lib/supabase';
import { useScrollAnimation } from './useScrollAnimation';

export default function Contact() {
  const [formData, setFormData] = useState<ContactSubmission>({ name: '', email: '', message: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const titleRef = useScrollAnimation();
  const formRef = useScrollAnimation();
  const infoRef = useScrollAnimation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const { error } = await supabase.from('contact_submissions').insert([formData]);
      if (error) throw error;
      setSubmitStatus('success');
      setFormData({ name: '', email: '', message: '' });
      setTimeout(() => setSubmitStatus('idle'), 5000);
    } catch {
      setSubmitStatus('error');
      setTimeout(() => setSubmitStatus('idle'), 5000);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <section id="contact" className="py-24 bg-black">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div ref={titleRef} className="text-center mb-16">
          <p className="text-yellow-400 text-xs font-bold uppercase tracking-[0.3em] mb-3">Reach Us</p>
          <h2 className="text-4xl md:text-5xl font-black text-white uppercase">
            Get In <span className="text-yellow-400">Touch</span>
          </h2>
          <p className="text-gray-500 mt-4 max-w-xl mx-auto text-sm">
            Ready to start your project? Let's talk about how we can help you.
          </p>
        </div>

        <div className="grid md:grid-cols-5 gap-12">
          <div ref={formRef} className="md:col-span-3">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <input
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  placeholder="Your Name"
                  className="bg-white/5 border border-white/10 text-white placeholder-gray-500 px-4 py-3 text-sm focus:outline-none focus:border-yellow-400 transition-colors w-full"
                />
                <input
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  placeholder="Your Email"
                  className="bg-white/5 border border-white/10 text-white placeholder-gray-500 px-4 py-3 text-sm focus:outline-none focus:border-yellow-400 transition-colors w-full"
                />
              </div>
              <textarea
                name="message"
                value={formData.message}
                onChange={handleChange}
                required
                rows={6}
                placeholder="Your Message"
                className="bg-white/5 border border-white/10 text-white placeholder-gray-500 px-4 py-3 text-sm focus:outline-none focus:border-yellow-400 transition-colors w-full resize-none"
              />
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex items-center gap-2 bg-yellow-400 text-black font-black text-sm uppercase tracking-widest px-8 py-4 hover:bg-yellow-300 transition-colors disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
                {isSubmitting ? 'Sending...' : 'Send Message'}
              </button>

              {submitStatus === 'success' && (
                <p className="text-yellow-400 text-sm font-bold">✓ Message sent successfully!</p>
              )}
              {submitStatus === 'error' && (
                <p className="text-red-400 text-sm font-bold">✗ Something went wrong. Please try again.</p>
              )}
            </form>
          </div>

          <div ref={infoRef} className="md:col-span-2 space-y-8">
            {[
              { icon: Mail, label: 'Email', value: 'contact@codecraft.com' },
              { icon: Phone, label: 'Phone', value: '+63 912 345 6789' },
              { icon: MapPin, label: 'Location', value: 'Philippines' },
            ].map(({ icon: Icon, label, value }) => (
              <div key={label} className="flex items-start gap-4">
                <div className="w-10 h-10 bg-yellow-400 flex items-center justify-center flex-shrink-0">
                  <Icon className="w-5 h-5 text-black" />
                </div>
                <div>
                  <p className="text-gray-500 text-xs uppercase tracking-widest mb-1">{label}</p>
                  <p className="text-white text-sm font-semibold">{value}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
