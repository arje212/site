import { useEffect, useState } from 'react';
import { ExternalLink } from 'lucide-react';
import { supabase, type Project } from '../lib/supabase';
import { useScrollAnimation } from './useScrollAnimation';

const fallbackProjects: Project[] = [
  { id: '1', title: 'E-Commerce Platform', description: 'Full-stack online shopping platform with payment integration.', technologies: ['React', 'Node.js', 'PostgreSQL'], image_url: 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=800', project_url: '#', display_order: 1 },
  { id: '2', title: 'Healthcare Management', description: 'Patient management system for clinics and hospitals.', technologies: ['Vue.js', 'Laravel', 'MySQL'], image_url: 'https://images.pexels.com/photos/4386467/pexels-photo-4386467.jpeg?auto=compress&cs=tinysrgb&w=800', project_url: '#', display_order: 2 },
  { id: '3', title: 'Mobile Banking App', description: 'Secure mobile banking application with real-time transactions.', technologies: ['React Native', 'Firebase'], image_url: 'https://images.pexels.com/photos/4427899/pexels-photo-4427899.jpeg?auto=compress&cs=tinysrgb&w=800', project_url: '#', display_order: 3 },
  { id: '4', title: 'Inventory System', description: 'Real-time inventory tracking and management system.', technologies: ['Next.js', 'Supabase', 'Tailwind'], image_url: 'https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=800', project_url: '#', display_order: 4 },
  { id: '5', title: 'Learning Management', description: 'Online learning platform with video streaming and quizzes.', technologies: ['React', 'Django', 'AWS'], image_url: 'https://images.pexels.com/photos/4144923/pexels-photo-4144923.jpeg?auto=compress&cs=tinysrgb&w=800', project_url: '#', display_order: 5 },
  { id: '6', title: 'Real Estate Portal', description: 'Property listing and management portal with map integration.', technologies: ['Next.js', 'MongoDB', 'Google Maps'], image_url: 'https://images.pexels.com/photos/1546168/pexels-photo-1546168.jpeg?auto=compress&cs=tinysrgb&w=800', project_url: '#', display_order: 6 },
];

export default function Projects() {
  const [projects, setProjects] = useState<Project[]>([]);
  const titleRef = useScrollAnimation();

  useEffect(() => {
    async function fetchProjects() {
      try {
        const { data, error } = await supabase.from('projects').select('*').order('display_order');
        if (error || !data || data.length === 0) {
          setProjects(fallbackProjects);
        } else {
          setProjects(data);
        }
      } catch {
        setProjects(fallbackProjects);
      }
    }
    fetchProjects();
  }, []);

  return (
    <section id="projects" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div ref={titleRef} className="text-center mb-16">
          <p className="text-yellow-500 text-xs font-bold uppercase tracking-[0.3em] mb-3">Portfolio</p>
          <h2 className="text-4xl md:text-5xl font-black text-black uppercase">
            Recent <span className="text-yellow-400">Projects</span>
          </h2>
          <p className="text-gray-500 mt-4 max-w-xl mx-auto text-sm">
            Showcasing our expertise through successful projects and innovative solutions
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-1">
          {projects.map((project, index) => (
            <ProjectCard key={project.id} project={project} delay={index * 80} />
          ))}
        </div>
      </div>
    </section>
  );
}

function ProjectCard({ project, delay }: { project: Project; delay: number }) {
  const ref = useScrollAnimation();
  return (
    <div
      ref={ref}
      style={{ transitionDelay: `${delay}ms` }}
      className="group relative overflow-hidden aspect-square bg-gray-100"
    >
      <img
        src={project.image_url}
        alt={project.title}
        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
      />
      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/75 transition-all duration-300 flex items-center justify-center">
        <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 text-center p-4">
          <h3 className="text-white font-black text-sm uppercase tracking-wide mb-2">{project.title}</h3>
          <div className="flex flex-wrap gap-1 justify-center mb-3">
            {project.technologies.slice(0, 2).map((t, i) => (
              <span key={i} className="text-xs bg-yellow-400 text-black px-2 py-0.5 font-bold">{t}</span>
            ))}
          </div>
          {project.project_url && (
            <a href={project.project_url} className="inline-flex items-center gap-1 text-yellow-400 text-xs font-bold uppercase">
              View <ExternalLink className="w-3 h-3" />
            </a>
          )}
        </div>
      </div>
    </div>
  );
}
