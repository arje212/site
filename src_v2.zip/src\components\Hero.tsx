import { useEffect, useRef } from 'react';

export default function Hero() {
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = heroRef.current;
    if (!el) return;
    el.style.opacity = '0';
    el.style.transform = 'translateY(40px)';
    setTimeout(() => {
      el.style.transition = 'opacity 1s ease, transform 1s ease';
      el.style.opacity = '1';
      el.style.transform = 'translateY(0)';
    }, 100);
  }, []);

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden bg-black">
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center opacity-40"
        style={{ backgroundImage: "url('https://images.pexels.com/photos/3183150/pexels-photo-3183150.jpeg?auto=compress&cs=tinysrgb&w=1920')" }}
      />
      {/* Yellow accent bar */}
      <div className="absolute left-0 top-0 bottom-0 w-1 bg-yellow-400" />

      <div ref={heroRef} className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 py-32">
        <p className="text-yellow-400 text-sm font-bold uppercase tracking-[0.3em] mb-6">
          Business Solution
        </p>
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-black text-white leading-none mb-8 max-w-3xl">
          We Help to
          <br />
          Build You
          <br />
          <span className="text-yellow-400">the Product</span>
        </h1>
        <p className="text-gray-300 text-lg max-w-xl mb-10 leading-relaxed">
          We are a team of passionate Computer Engineers crafting innovative websites,
          web applications, and IT solutions that drive business growth.
        </p>
        <div className="flex flex-wrap gap-4">
          <button
            onClick={() => scrollToSection('contact')}
            className="px-8 py-4 bg-yellow-400 text-black font-bold text-sm uppercase tracking-widest hover:bg-yellow-300 transition-colors"
          >
            Get Started
          </button>
          <button
            onClick={() => scrollToSection('projects')}
            className="px-8 py-4 bg-transparent text-white font-bold text-sm uppercase tracking-widest border-2 border-white hover:border-yellow-400 hover:text-yellow-400 transition-colors"
          >
            View Projects
          </button>
        </div>
      </div>

      {/* Stats bar */}
      <div className="absolute bottom-0 left-0 right-0 bg-black/80 border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-6 grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { number: '50+', label: 'Projects Completed' },
            { number: '30+', label: 'Happy Clients' },
            { number: '6', label: 'Team Members' },
            { number: '5+', label: 'Years Experience' },
          ].map((stat, i) => (
            <div key={i} className="text-center">
              <div className="text-3xl font-black text-yellow-400">{stat.number}</div>
              <div className="text-xs text-gray-400 uppercase tracking-widest mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
