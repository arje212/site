import { Code2, Mail, Phone, MapPin } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();
  const scrollToSection = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });

  return (
    <footer className="bg-gray-950 text-gray-400 border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="bg-yellow-400 p-1.5">
                <Code2 className="w-5 h-5 text-black" />
              </div>
              <span className="text-xl font-black text-white uppercase tracking-tight">
                Code<span className="text-yellow-400">Craft</span>
              </span>
            </div>
            <p className="text-sm leading-relaxed mb-6">
              Innovating Digital Solutions Through Engineering Excellence.
            </p>
            <div className="flex gap-2">
              {['in', 'gh', 'tw', 'fb'].map((s) => (
                <a key={s} href="#"
                  className="w-8 h-8 border border-gray-700 flex items-center justify-center text-xs font-bold uppercase hover:border-yellow-400 hover:text-yellow-400 transition-colors">
                  {s}
                </a>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-white font-black text-xs uppercase tracking-[0.2em] mb-5">Quick Links</h3>
            <ul className="space-y-2">
              {['Home', 'About', 'Services', 'Projects', 'Team', 'Contact'].map((link) => (
                <li key={link}>
                  <button onClick={() => scrollToSection(link.toLowerCase())}
                    className="text-sm hover:text-yellow-400 transition-colors">
                    {link}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-white font-black text-xs uppercase tracking-[0.2em] mb-5">Services</h3>
            <ul className="space-y-2 text-sm">
              {['Website Development', 'Web Applications', 'System Development', 'UI/UX Design', 'IT Consulting'].map((s) => (
                <li key={s} className="hover:text-yellow-400 transition-colors cursor-pointer">{s}</li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-white font-black text-xs uppercase tracking-[0.2em] mb-5">Contact</h3>
            <ul className="space-y-3 text-sm">
              {[
                { icon: Mail, text: 'contact@codecraft.com' },
                { icon: Phone, text: '+63 912 345 6789' },
                { icon: MapPin, text: 'Philippines' },
              ].map(({ icon: Icon, text }) => (
                <li key={text} className="flex items-center gap-2">
                  <Icon className="w-4 h-4 text-yellow-400 flex-shrink-0" />
                  <span>{text}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs">
          <p>&copy; {currentYear} CodeCraft. All rights reserved.</p>
          <p>Built with passion by our team.</p>
        </div>
      </div>
    </footer>
  );
}
