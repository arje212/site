import { Globe, Smartphone, Code2, Paintbrush, Headphones, Wrench } from 'lucide-react';

export default function Services() {
  const services = [
    {
      icon: Globe,
      title: 'Website Development',
      description: 'Custom, responsive websites built with modern technologies to establish your online presence.',
      features: ['Responsive Design', 'SEO Optimization', 'Performance Focused', 'CMS Integration'],
    },
    {
      icon: Smartphone,
      title: 'Web Application Development',
      description: 'Full-stack web applications tailored to your business needs with scalable architecture.',
      features: ['Custom Solutions', 'Real-time Features', 'Cloud Integration', 'API Development'],
    },
    {
      icon: Code2,
      title: 'System Development',
      description: 'Enterprise-grade systems and software solutions designed for efficiency and growth.',
      features: ['Database Design', 'System Architecture', 'Integration Services', 'Automation'],
    },
    {
      icon: Paintbrush,
      title: 'UI/UX Design',
      description: 'User-centered design that creates engaging and intuitive digital experiences.',
      features: ['User Research', 'Wireframing', 'Prototyping', 'Visual Design'],
    },
    {
      icon: Headphones,
      title: 'IT Consulting',
      description: 'Strategic technology guidance to help you make informed decisions and optimize processes.',
      features: ['Tech Strategy', 'Architecture Review', 'Best Practices', 'Digital Transformation'],
    },
    {
      icon: Wrench,
      title: 'Maintenance & Support',
      description: 'Ongoing support and maintenance to keep your systems running smoothly and securely.',
      features: ['24/7 Monitoring', 'Bug Fixes', 'Updates', 'Performance Optimization'],
    },
  ];

  return (
    <section id="services" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            Our <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Services</span>
          </h2>
          <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive technology solutions designed to bring your vision to life
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-white rounded-xl p-8 shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              <div className="w-14 h-14 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center mb-6">
                <service.icon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
              <p className="text-gray-600 mb-6">{service.description}</p>
              <ul className="space-y-2">
                {service.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center text-sm text-gray-600">
                    <div className="w-1.5 h-1.5 bg-blue-600 rounded-full mr-2"></div>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
