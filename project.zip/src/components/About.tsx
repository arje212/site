import { Code, Database, Palette, Shield } from 'lucide-react';

export default function About() {
  const features = [
    {
      icon: Code,
      title: 'Frontend Excellence',
      description: 'Creating beautiful, responsive interfaces with modern frameworks and best practices.',
    },
    {
      icon: Database,
      title: 'Backend Mastery',
      description: 'Building scalable, secure server architectures and robust APIs.',
    },
    {
      icon: Palette,
      title: 'UI/UX Design',
      description: 'Designing intuitive experiences that users love and engage with.',
    },
    {
      icon: Shield,
      title: 'System Security',
      description: 'Implementing industry-standard security practices to protect your data.',
    },
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            About <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">CodeCraft</span>
          </h2>
          <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
            We are a passionate team of Computer Engineers dedicated to transforming ideas into
            exceptional digital solutions through innovation, expertise, and cutting-edge technology.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 lg:gap-12 mb-16">
          <div className="space-y-6">
            <h3 className="text-2xl md:text-3xl font-bold text-gray-900">Our Mission</h3>
            <p className="text-gray-600 leading-relaxed">
              At CodeCraft, we believe in the power of technology to solve real-world problems.
              Our mission is to deliver innovative, scalable, and user-friendly solutions that
              help businesses thrive in the digital age.
            </p>
            <p className="text-gray-600 leading-relaxed">
              With expertise spanning frontend development, backend systems, database management,
              and UI/UX design, we approach every project with a commitment to excellence and
              attention to detail.
            </p>
          </div>

          <div className="space-y-6">
            <h3 className="text-2xl md:text-3xl font-bold text-gray-900">Our Approach</h3>
            <p className="text-gray-600 leading-relaxed">
              We combine technical expertise with creative problem-solving to build solutions
              that are not only functional but also elegant and intuitive. Our collaborative
              approach ensures that we understand your needs and deliver results that exceed
              expectations.
            </p>
            <p className="text-gray-600 leading-relaxed">
              From initial concept to final deployment and ongoing support, we're with you
              every step of the way, ensuring your digital solutions remain cutting-edge and
              effective.
            </p>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div
              key={index}
              className="p-6 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl hover:shadow-lg transition-shadow duration-300"
            >
              <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center mb-4">
                <feature.icon className="w-6 h-6 text-white" />
              </div>
              <h4 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h4>
              <p className="text-gray-600 text-sm">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
